import { getLoginUrl, getLoginUrlWithReturn } from "@/const";
import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useMemo } from "react";
import { isObserver } from "@shared/observer-policy";
import { observerViewUser } from "@shared/observer-view";
import {
  AUTH_RECOVERY_INTERVAL_MS,
  authRetryDelay,
  getAuthFailureKind,
  isRecoverableAuthFailure,
  shouldRetryAuthQuery,
} from "@/lib/auth-query-policy";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = getLoginUrl() } =
    options ?? {};
  const utils = trpc.useUtils();

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: shouldRetryAuthQuery,
    retryDelay: authRetryDelay,
    refetchOnWindowFocus: false,
    refetchInterval: query => isRecoverableAuthFailure(query.state.error)
      ? AUTH_RECOVERY_INTERVAL_MS
      : false,
    refetchIntervalInBackground: false,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.setData(undefined, null);
    },
  });

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        return;
      }
      throw error;
    } finally {
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
    }
  }, [logoutMutation, utils]);

  const state = useMemo(() => {
    localStorage.setItem(
      "manus-runtime-user-info",
      JSON.stringify(meQuery.data)
    );
    return {
      user: observerViewUser(meQuery.data),
      authenticatedUser: meQuery.data ?? null,
      isReadOnly: isObserver(meQuery.data?.role),
      loading: meQuery.isLoading || logoutMutation.isPending,
      error: meQuery.error ?? logoutMutation.error ?? null,
      authFailureKind: getAuthFailureKind(meQuery.error ?? logoutMutation.error),
      isAuthenticated: Boolean(meQuery.data),
    };
  }, [
    meQuery.data,
    meQuery.error,
    meQuery.isLoading,
    logoutMutation.error,
    logoutMutation.isPending,
  ]);

  useEffect(() => {
    if (!redirectOnUnauthenticated) return;
    if (meQuery.isLoading || logoutMutation.isPending) return;
    // A failed auth check can be a temporary server/DB problem. Only a
    // successful auth.me response with no user is evidence of no session.
    if (meQuery.error) return;
    if (state.user) return;
    if (typeof window === "undefined") return;
    if (window.location.pathname === redirectPath) return;

    window.location.href = redirectPath === getLoginUrl()
      ? getLoginUrlWithReturn(window.location.pathname + window.location.search)
      : redirectPath;
  }, [
    redirectOnUnauthenticated,
    redirectPath,
    logoutMutation.isPending,
    meQuery.isLoading,
    meQuery.error,
    state.user,
  ]);

  return {
    ...state,
    refresh: () => meQuery.refetch(),
    logout,
  };
}
