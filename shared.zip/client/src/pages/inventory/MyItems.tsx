import { trpc } from "@/lib/trpc";
import { independentReadOptions } from "@/lib/read-transport";
import { refreshPurchaseExecution, purchaseRefreshNotice } from "@/lib/purchaseExecutionRefresh";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ShoppingBag, Package, Clock, CheckCircle2, Camera,
  Loader2, AlertCircle, DollarSign, FileText, Truck, FileDown
} from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { useOfflineUpload } from "@/hooks/useOfflineUpload";
import { Wifi, WifiOff, CloudUpload } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useTranslation, useLanguage } from "@/contexts/LanguageContext";
import { getLocalizedItemField } from "@/hooks/useContentTranslation";

type ItemStatus = "pending" | "estimated" | "approved" | "purchased" | "received";

const PAGE_SIZE = 15;

// نفس أسلوب الترقيم المستخدم بصفحتي دورة الشراء والصيانة الخارجية.
function Pagination({ total, page, setPage }: { total: number; page: number; setPage: (p: number) => void }) {
  const pages = Math.ceil(total / PAGE_SIZE);
  if (pages <= 1) return null;
  const shown = new Set<number>([1, pages]);
  for (let p = page - 1; p <= page + 1; p++) if (p > 1 && p < pages) shown.add(p);
  const sorted = Array.from(shown).sort((a, b) => a - b);
  const items: (number | "gap")[] = [];
  let prev = 0;
  for (const p of sorted) {
    if (prev && p - prev > 1) items.push("gap");
    items.push(p);
    prev = p;
  }
  return (
    <div className="flex items-center justify-center gap-1 mt-3 flex-wrap">
      <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
      {items.map((it, i) => it === "gap" ? (
        <span key={`gap-${i}`} className="px-1 text-muted-foreground text-sm">…</span>
      ) : (
        <Button key={it} variant={it === page ? "default" : "outline"} size="sm" className="w-8 h-8 p-0" onClick={() => setPage(it as number)}>{it}</Button>
      ))}
      <Button variant="outline" size="sm" disabled={page === pages} onClick={() => setPage(page + 1)}>التالي</Button>
    </div>
  );
}

function numberToWords(num: number, language: string): string {
  if (language === "ar") {
    if (num === 0) return "صفر ريال";
    const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
    const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
    const tens = ["", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
    const hundreds = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];
    const n = Math.floor(num);
    const parts: string[] = [];
    if (n >= 1000) { const t = Math.floor(n / 1000); parts.push(t === 1 ? "ألف" : t === 2 ? "ألفان" : ones[t] + " آلاف"); }
    const rem = n % 1000;
    if (rem >= 100) parts.push(hundreds[Math.floor(rem / 100)]);
    const r = rem % 100;
    if (r >= 10 && r < 20) parts.push(teens[r - 10]);
    else { if (r % 10 > 0) parts.push(ones[r % 10]); if (r >= 20) parts.push(tens[Math.floor(r / 10)]); }
    return parts.join(" و") + " ريال";
  }
  if (language === "en") {
    if (num === 0) return "Zero SAR";
    const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
      "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    const n = Math.floor(num);
    const parts: string[] = [];
    if (n >= 1000) parts.push(ones[Math.floor(n / 1000)] + " Thousand");
    const rem = n % 1000;
    if (rem >= 100) parts.push(ones[Math.floor(rem / 100)] + " Hundred");
    const r = rem % 100;
    if (r > 0 && r < 20) parts.push(ones[r]);
    else if (r >= 20) parts.push(tens[Math.floor(r / 10)] + (r % 10 > 0 ? "-" + ones[r % 10] : ""));
    return parts.join(" ") + " SAR";
  }
  // Urdu fallback — show numeric
  return `${num.toLocaleString("ur-PK")} روپے`;
}

export default function MyItems() {
  const { t: tr } = useLanguage();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { t, language } = useTranslation();
  const locale = language === "ar" ? "ar-SA" : language === "ur" ? "ur-PK" : "en-US";
  const currency = t.common.currency;
  const utils = trpc.useUtils();

  const { data: myItems, isLoading, refetch } = trpc.purchaseOrders.myItems.useQuery(undefined, {
    enabled: user?.role === "delegate" || user?.role === "admin" || user?.role === "owner",
    ...independentReadOptions,
  });

  const [exportingPdf, setExportingPdf] = useState(false);

  const handleExportPdf = async () => {
    setExportingPdf(true);
    try {
      const res = await fetch("/api/export/my-items-pdf", { credentials: "include" });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `my-items-${new Date().toISOString().slice(0, 10)}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(t.myItems.exportPdfSuccess);
    } catch {
      toast.error(t.myItems.exportPdfFailed);
    } finally {
      setExportingPdf(false);
    }
  };

  const handleExportPricingPdf = async () => {
    if (!pricingExportPoId) return;
    setExportingPricingPdf(true);
    try {
      const res = await fetch(`/api/export/po/${pricingExportPoId}/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `pricing-${new Date().toISOString().slice(0, 10)}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(t.myItems.exportPdfSuccess);
      setShowPricingExportButton(false);
      setPricingExportPoId(null);
    } catch (err) {
      toast.error(t.myItems.exportPdfFailed);
    } finally {
      setExportingPricingPdf(false);
    }
  };

  const [activeTab, setActiveTab] = useState("pending_estimate");
  const [estimateDialog, setEstimateDialog] = useState<any>(null);
  const [estimateCost, setEstimateCost] = useState("");
  const [purchaseDialog, setPurchaseDialog] = useState<any>(null);
  const [uploadingField, setUploadingField] = useState<string | null>(null);
  const [invoiceUrl, setInvoiceUrl] = useState("");
  const [purchasedUrl, setPurchasedUrl] = useState("");

  // ── Offline-first upload ─────────────────────────────────────────────────
  const { uploadImage, isOnline, pendingCount, isSyncing, syncPending } = useOfflineUpload();

  // استمع لحدث المزامنة من Service Worker
  useEffect(() => {
    const handleSynced = (e: CustomEvent) => {
      const { field, url } = e.detail;
      if (field === "invoice") setInvoiceUrl(url);
      if (field === "purchased") setPurchasedUrl(url);
      refetch();
    };
    const handleSwMessage = (e: MessageEvent) => {
      if (e.data?.type === "CMMS_SYNC_UPLOADS") syncPending();
    };
    window.addEventListener("cmms:upload:synced", handleSynced as EventListener);
    navigator.serviceWorker?.addEventListener("message", handleSwMessage);
    return () => {
      window.removeEventListener("cmms:upload:synced", handleSynced as EventListener);
      navigator.serviceWorker?.removeEventListener("message", handleSwMessage);
    };
  }, [syncPending]);
  const [showPricingExportButton, setShowPricingExportButton] = useState(false);
  const [pricingExportPoId, setPricingExportPoId] = useState<number | null>(null);
  const [exportingPricingPdf, setExportingPricingPdf] = useState(false);

  const estimateMut = trpc.purchaseOrders.estimateCost.useMutation({
    onSuccess: (_, variables) => {
      toast.success(t.common.save);
      setShowPricingExportButton(true);
      setPricingExportPoId(variables.purchaseOrderId);
      setEstimateDialog(null);
      setEstimateCost("");
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const confirmPurchaseMut = trpc.purchaseOrders.confirmItemPurchase.useMutation({
    onSuccess: async (result, variables) => {
      toast.success(t.common.confirm);
      setPurchaseDialog(null);
      setInvoiceUrl("");
      setPurchasedUrl("");
      if (!await refreshPurchaseExecution(utils, result, variables)) toast.warning(purchaseRefreshNotice(language));
    },
    onError: (err) => toast.error(err.message),
  });

  const handleUpload = async (field: "invoice" | "purchased", file: File) => {
    setUploadingField(field);
    try {
      const result = await uploadImage(file, { field, itemId: purchaseDialog?.id });

      if (result.uploaded && result.url) {
        // رُفع مباشرة — حدّث الـ URL فوراً
        if (field === "invoice") setInvoiceUrl(result.url);
        else setPurchasedUrl(result.url);
        toast.success("✅ " + t.common.upload);
      } else {
        const placeholder = `__offline__${field}__${Date.now()}`;
        if (field === "invoice") setInvoiceUrl(placeholder);
        else setPurchasedUrl(placeholder);
        toast.success("💾 " + t.myItems.offlinePurchaseQueued, {
          duration: 5000,
        });
      }
    } catch {
      toast.error(t.myItems.savePhotoFailed);
    }
    setUploadingField(null);
  };

  const grouped = useMemo(() => {
    if (!myItems) return { pending_estimate: [], approved: [], purchased: [], received: [] };
    const items = myItems as any[];
    return {
      pending_estimate: items.filter((i: any) => i.status === "pending" || i.status === "estimated"),
      approved: items.filter((i: any) => i.status === "approved"),
      purchased: items.filter((i: any) => i.status === "purchased"),
      received: items.filter((i: any) => i.status === "received"),
    };
  }, [myItems]);

  const tabCounts = {
    pending_estimate: grouped.pending_estimate.length,
    approved: grouped.approved.length,
    purchased: grouped.purchased.length,
    received: grouped.received.length,
  };

  const [pagePendingEstimate, setPagePendingEstimate] = useState(1);
  const [pageApproved, setPageApproved] = useState(1);
  const [pagePurchased, setPagePurchased] = useState(1);
  const [pageReceived, setPageReceived] = useState(1);

  const pagedPendingEstimate = grouped.pending_estimate.slice((pagePendingEstimate - 1) * PAGE_SIZE, pagePendingEstimate * PAGE_SIZE);
  const pagedApproved = grouped.approved.slice((pageApproved - 1) * PAGE_SIZE, pageApproved * PAGE_SIZE);
  const pagedPurchased = grouped.purchased.slice((pagePurchased - 1) * PAGE_SIZE, pagePurchased * PAGE_SIZE);
  const pagedReceived = grouped.received.slice((pageReceived - 1) * PAGE_SIZE, pageReceived * PAGE_SIZE);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}</div>
      </div>
    );
  }

  const statusBorderColor = (status: string) =>
    status === "approved" ? "border-emerald-400" : status === "purchased" ? "border-purple-400" :
    status === "received" ? "border-green-400" : "border-amber-400";

  const renderItem = (item: any) => {
    const name = getLocalizedItemField(item, "itemName", language);
    return (
      <Card key={item.id} className={`hover:shadow-md transition-all duration-200 border-r-4 ${statusBorderColor(item.status)}`}>
        <CardContent className="p-3">
          <div className="flex flex-col sm:flex-row gap-3">
            {/* صورة مصغّرة بمقاس ثابت (مربّعة) بدل الشريط الممطوط اللي كان يقصّ الصورة */}
            <div className="w-full h-28 sm:w-20 sm:h-20 shrink-0 rounded-lg overflow-hidden bg-muted border">
              {item.photoUrl ? (
                <img src={item.photoUrl} alt={name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground/30">
                  <Package className="w-6 h-6" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-semibold text-sm truncate">{name}</h3>
                <Badge className="shrink-0 text-[10px]">{item.status}</Badge>
              </div>
              {item.description && (
                <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{getLocalizedItemField(item, "description", language)}</p>
              )}

              {/* بيانات مختصرة بسطر واحد بدل 4 صناديق منفصلة تاخذ مساحة كبيرة */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs mt-2">
                <span className="text-muted-foreground">{t.purchaseOrders.quantity}: <b className="text-foreground">{item.quantity} {item.unit || ""}</b></span>
                <Button variant="link" className="h-auto p-0 text-xs" onClick={() => setLocation(`/purchase-orders/${item.purchaseOrderId}`)}>
                  {t.purchaseOrders.poNumber} #{item.purchaseOrderId}
                </Button>
                {item.estimatedUnitCost && (
                  <span className="text-muted-foreground">{t.purchaseOrders.estimatedUnitCost}: <b className="text-foreground">{parseFloat(item.estimatedUnitCost).toLocaleString(locale)} {currency}</b></span>
                )}
                {item.estimatedTotalCost && (
                  <span className="text-muted-foreground">{t.purchaseOrders.estimatedTotal}: <b className="text-foreground">{parseFloat(item.estimatedTotalCost).toLocaleString(locale)} {currency}</b></span>
                )}
                {item.status === "received" && item.actualUnitCost && (
                  <span className="text-green-700 font-semibold">{parseFloat(item.actualUnitCost).toLocaleString(locale)} {currency}</span>
                )}
              </div>

              {item.notes && (
                <p className="text-[11px] text-muted-foreground bg-muted/30 rounded-md px-2 py-1 mt-2 line-clamp-1">
                  <FileText className="w-3 h-3 inline ml-1" />{getLocalizedItemField(item, "notes", language)}
                </p>
              )}
            </div>

            {/* زر الإجراء مضغوط بدل الشريط الكامل العرض */}
            <div className="shrink-0 flex sm:items-center">
              {item.status === "pending" && (
                <Button size="sm" className="w-full sm:w-auto gap-1.5 bg-amber-600 hover:bg-amber-700" onClick={() => { setEstimateDialog(item); setEstimateCost(""); }}>
                  <DollarSign className="w-3.5 h-3.5" /> {t.purchaseOrders.estimatedUnitCost}
                </Button>
              )}
              {item.status === "approved" && (
                <Button size="sm" className="w-full sm:w-auto gap-1.5 bg-emerald-600 hover:bg-emerald-700" onClick={() => { setPurchaseDialog(item); setInvoiceUrl(""); setPurchasedUrl(""); }}>
                  <ShoppingBag className="w-3.5 h-3.5" /> {t.purchaseOrders.confirmPurchase}
                </Button>
              )}
              {item.status === "purchased" && (
                <Badge variant="outline" className="gap-1.5 text-purple-700 border-purple-200 bg-purple-50 whitespace-nowrap">
                  <Truck className="w-3.5 h-3.5" /> {t.purchaseOrders.confirmPurchase}
                </Badge>
              )}
              {item.status === "received" && (
                <Badge variant="outline" className="gap-1.5 text-green-700 border-green-200 bg-green-50 whitespace-nowrap">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {t.purchaseOrders.receiveItem}
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-primary" /> {t.nav.myItems}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{t.purchaseOrders.items}</p>

          {/* ── مؤشر الاتصال ── */}
          <div className="flex items-center gap-2 mt-2">
            {isOnline ? (
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-full px-2.5 py-0.5">
                <Wifi className="w-3 h-3" />
                {t.common.active}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-2.5 py-0.5">
                <WifiOff className="w-3 h-3" />
                {t.common.inactive}
              </span>
            )}
            {pendingCount > 0 && (
              <span
                className="inline-flex items-center gap-1.5 text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-full px-2.5 py-0.5 cursor-pointer hover:bg-blue-100 transition-colors"
                onClick={() => isOnline && syncPending()}
                title={t.myItems.syncNow}
              >
                <CloudUpload className="w-3 h-3" />
                {isSyncing ? t.myItems.syncing : `${pendingCount} ${t.myItems.pendingUpload}`}
              </span>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          {showPricingExportButton && (
            <Button
              variant="default"
              size="sm"
              className="gap-2 shrink-0 bg-emerald-600 hover:bg-emerald-700"
              onClick={handleExportPricingPdf}
              disabled={exportingPricingPdf}
            >
              {exportingPricingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
              {t.myItems.exportPricing}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            className="gap-2 shrink-0"
            onClick={handleExportPdf}
            disabled={exportingPdf || !myItems || (myItems as any[]).length === 0}
          >
            {exportingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
            {t.myItems.exportPdf}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-amber-200 bg-amber-50/50 cursor-pointer hover:shadow-md transition-all" onClick={() => setActiveTab("pending_estimate")}>
          <CardContent className="p-3 text-center">
            <Clock className="w-5 h-5 mx-auto text-amber-600 mb-1" />
            <p className="text-2xl font-bold text-amber-800">{tabCounts.pending_estimate}</p>
            <p className="text-[10px] text-amber-600">{t.purchaseOrders.estimatedUnitCost}</p>
          </CardContent>
        </Card>
        <Card className="border-emerald-200 bg-emerald-50/50 cursor-pointer hover:shadow-md transition-all" onClick={() => setActiveTab("approved")}>
          <CardContent className="p-3 text-center">
            <CheckCircle2 className="w-5 h-5 mx-auto text-emerald-600 mb-1" />
            <p className="text-2xl font-bold text-emerald-800">{tabCounts.approved}</p>
            <p className="text-[10px] text-emerald-600">{t.purchaseOrders.confirmPurchase}</p>
          </CardContent>
        </Card>
        <Card className="border-purple-200 bg-purple-50/50 cursor-pointer hover:shadow-md transition-all" onClick={() => setActiveTab("purchased")}>
          <CardContent className="p-3 text-center">
            <ShoppingBag className="w-5 h-5 mx-auto text-purple-600 mb-1" />
            <p className="text-2xl font-bold text-purple-800">{tabCounts.purchased}</p>
            <p className="text-[10px] text-purple-600">{t.purchaseOrders.confirmPurchase}</p>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50/50 cursor-pointer hover:shadow-md transition-all" onClick={() => setActiveTab("received")}>
          <CardContent className="p-3 text-center">
            <Package className="w-5 h-5 mx-auto text-green-600 mb-1" />
            <p className="text-2xl font-bold text-green-800">{tabCounts.received}</p>
            <p className="text-[10px] text-green-600">{t.purchaseOrders.receiveItem}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="pending_estimate" className="text-xs gap-1">
            <Clock className="w-3 h-3" /> {t.purchaseOrders.estimatedUnitCost}
            {tabCounts.pending_estimate > 0 && <Badge variant="secondary" className="text-[9px] h-4 px-1">{tabCounts.pending_estimate}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="approved" className="text-xs gap-1">
            <CheckCircle2 className="w-3 h-3" /> {t.purchaseOrders.confirmPurchase}
            {tabCounts.approved > 0 && <Badge variant="secondary" className="text-[9px] h-4 px-1">{tabCounts.approved}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="purchased" className="text-xs gap-1">
            <ShoppingBag className="w-3 h-3" /> {t.purchaseOrders.confirmPurchase}
            {tabCounts.purchased > 0 && <Badge variant="secondary" className="text-[9px] h-4 px-1">{tabCounts.purchased}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="received" className="text-xs gap-1">
            <Package className="w-3 h-3" /> {t.purchaseOrders.receiveItem}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending_estimate" className="space-y-3 mt-4">
          {grouped.pending_estimate.length === 0 ? (
            <Card><CardContent className="p-8 text-center">
              <Clock className="w-10 h-10 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">{t.common.noData}</p>
            </CardContent></Card>
          ) : (
            <>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-center gap-2 text-xs text-amber-800">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{t.purchaseOrders.estimatedUnitCost}</span>
              </div>
              {pagedPendingEstimate.map(renderItem)}
              <Pagination total={grouped.pending_estimate.length} page={pagePendingEstimate} setPage={setPagePendingEstimate} />
            </>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-3 mt-4">
          {grouped.approved.length === 0 ? (
            <Card><CardContent className="p-8 text-center">
              <CheckCircle2 className="w-10 h-10 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">{t.common.noData}</p>
            </CardContent></Card>
          ) : (
            <>
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center gap-2 text-xs text-emerald-800">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{t.purchaseOrders.confirmPurchase}</span>
              </div>
              {pagedApproved.map(renderItem)}
              <Pagination total={grouped.approved.length} page={pageApproved} setPage={setPageApproved} />
            </>
          )}
        </TabsContent>

        <TabsContent value="purchased" className="space-y-3 mt-4">
          {grouped.purchased.length === 0 ? (
            <Card><CardContent className="p-8 text-center">
              <ShoppingBag className="w-10 h-10 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">{t.common.noData}</p>
            </CardContent></Card>
          ) : <>
            {pagedPurchased.map(renderItem)}
            <Pagination total={grouped.purchased.length} page={pagePurchased} setPage={setPagePurchased} />
          </>}
        </TabsContent>

        <TabsContent value="received" className="space-y-3 mt-4">
          {grouped.received.length === 0 ? (
            <Card><CardContent className="p-8 text-center">
              <Package className="w-10 h-10 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">{t.common.noData}</p>
            </CardContent></Card>
          ) : <>
            {pagedReceived.map(renderItem)}
            <Pagination total={grouped.received.length} page={pageReceived} setPage={setPageReceived} />
          </>}
        </TabsContent>
      </Tabs>

      <Dialog open={!!estimateDialog} onOpenChange={(open) => { if (!open) setEstimateDialog(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">{t.purchaseOrders.estimatedUnitCost}</DialogTitle>
          </DialogHeader>
          {estimateDialog && (
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="font-medium text-sm">{estimateDialog.itemName}</p>
                <p className="text-xs text-muted-foreground mt-1">{t.purchaseOrders.quantity}: {estimateDialog.quantity} {estimateDialog.unit || ""}</p>
              </div>
              <div className="space-y-2">
                <Label>{t.purchaseOrders.estimatedUnitCost} ({currency}) *</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={estimateCost}
                  onChange={e => setEstimateCost(e.target.value)}
                  className="text-lg font-bold"
                />
              </div>
              {estimateCost && parseFloat(estimateCost) > 0 && (
                <div className="bg-primary/5 rounded-lg p-3 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>{t.purchaseOrders.estimatedTotal}:</span>
                    <span className="font-bold text-lg">{(parseFloat(estimateCost) * estimateDialog.quantity).toLocaleString(locale)} {currency}</span>
                  </div>
                  <p className="text-xs text-muted-foreground text-left">
                    ({numberToWords(parseFloat(estimateCost) * estimateDialog.quantity, language)})
                  </p>
                </div>
              )}
              <Button
                className="w-full gap-2"
                onClick={() => {
                  if (!estimateCost || parseFloat(estimateCost) <= 0) { toast.error(t.purchaseOrders.estimatedUnitCost); return; }
                  estimateMut.mutate({
                    purchaseOrderId: estimateDialog.purchaseOrderId,
                    items: [{ id: estimateDialog.id, estimatedUnitCost: estimateCost }],
                  });
                }}
                disabled={estimateMut.isPending}
              >
                {estimateMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <DollarSign className="w-4 h-4" />}
                {t.common.save}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!purchaseDialog} onOpenChange={(open) => { if (!open) setPurchaseDialog(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">{t.purchaseOrders.confirmPurchase}</DialogTitle>
          </DialogHeader>
          {purchaseDialog && (
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-3">
                <p className="font-medium text-sm">{getLocalizedItemField(purchaseDialog, "itemName", language)}</p>
                <p className="text-xs text-muted-foreground mt-1">{t.purchaseOrders.quantity}: {purchaseDialog.quantity} {purchaseDialog.unit || ""}</p>
                {purchaseDialog.estimatedTotalCost && (
                  <p className="text-xs text-muted-foreground mt-1">{t.purchaseOrders.estimatedTotal}: {parseFloat(purchaseDialog.estimatedTotalCost).toLocaleString(locale)} {currency}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>{t.purchaseOrders.accountingNotes} *</Label>
                {invoiceUrl ? (
                  <div className="relative">
                    {invoiceUrl.startsWith("__offline__") ? (
                      <div className="w-full h-32 rounded-lg border bg-amber-50 border-amber-200 flex flex-col items-center justify-center gap-1">
                        <CloudUpload className="w-6 h-6 text-amber-600" />
                        <span className="text-xs text-amber-700 font-medium">{t.myItems.offlinePurchaseQueued}</span>
                      </div>
                    ) : (
                      <img src={invoiceUrl} alt="" className="w-full h-32 object-cover rounded-lg border" />
                    )}
                    <Button variant="destructive" size="icon" className="absolute top-1 left-1 h-6 w-6" onClick={() => setInvoiceUrl("")}>
                      <span className="text-xs">×</span>
                    </Button>
                  </div>
                ) : (
                  <Button variant="outline" className="w-full h-24 border-dashed gap-2" onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file"; input.accept = "image/*"; input.capture = "environment";
                    input.onchange = (e: any) => { if (e.target.files[0]) handleUpload("invoice", e.target.files[0]); };
                    input.click();
                  }} disabled={uploadingField === "invoice"}>
                    {uploadingField === "invoice" ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
                    {uploadingField === "invoice" ? t.myItems.compressingAndSaving : t.common.upload}
                  </Button>
                )}
              </div>

              <div className="space-y-2">
                <Label>{t.tickets.photos} *</Label>
                {purchasedUrl ? (
                  <div className="relative">
                    {purchasedUrl.startsWith("__offline__") ? (
                      <div className="w-full h-32 rounded-lg border bg-amber-50 border-amber-200 flex flex-col items-center justify-center gap-1">
                        <CloudUpload className="w-6 h-6 text-amber-600" />
                        <span className="text-xs text-amber-700 font-medium">{t.myItems.offlinePurchaseQueued}</span>
                      </div>
                    ) : (
                      <img src={purchasedUrl} alt="" className="w-full h-32 object-cover rounded-lg border" />
                    )}
                    <Button variant="destructive" size="icon" className="absolute top-1 left-1 h-6 w-6" onClick={() => setPurchasedUrl("")}>
                      <span className="text-xs">×</span>
                    </Button>
                  </div>
                ) : (
                  <Button variant="outline" className="w-full h-24 border-dashed gap-2" onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file"; input.accept = "image/*"; input.capture = "environment";
                    input.onchange = (e: any) => { if (e.target.files[0]) handleUpload("purchased", e.target.files[0]); };
                    input.click();
                  }} disabled={uploadingField === "purchased"}>
                    {uploadingField === "purchased" ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
                    {uploadingField === "purchased" ? t.myItems.compressingAndSaving : t.common.upload}
                  </Button>
                )}
              </div>

              {(invoiceUrl.startsWith("__offline__") || purchasedUrl.startsWith("__offline__")) && (
                <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <WifiOff className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>{t.myItems.offlinePurchaseQueued}</span>
                </div>
              )}

              <Button
                className="w-full gap-2"
                onClick={() => {
                  if (!invoiceUrl) { toast.error(t.common.upload); return; }
                  if (!purchasedUrl) { toast.error(t.common.upload); return; }
                  if (invoiceUrl.startsWith("__offline__") || purchasedUrl.startsWith("__offline__")) {
                    toast.info(t.myItems.offlinePurchaseQueued);
                    setPurchaseDialog(null);
                    return;
                  }
                  confirmPurchaseMut.mutate({
                    itemId: purchaseDialog.id,
                    invoicePhotoUrl: invoiceUrl,
                    purchasedPhotoUrl: purchasedUrl,
                  });
                }}
                disabled={confirmPurchaseMut.isPending}
              >
                {confirmPurchaseMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                {(invoiceUrl.startsWith("__offline__") || purchasedUrl.startsWith("__offline__"))
                  ? t.myItems.saveAndSendLater
                  : t.purchaseOrders.confirmPurchase}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
