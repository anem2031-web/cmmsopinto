export { default } from "./FollowupDashboard";
