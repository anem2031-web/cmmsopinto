// ============================================================
// قوالب طباعة مستندات عمليات المخزون (جرد / تسوية / استبعاد)
// مصدر واحد مشترك بين صفحة عمليات المخزون ومركز المستندات.
// يدعم بيانات Lot/QR في وثائق الجرد والتسوية عند تفعيل 2B-8،
// مع الحفاظ على عرض الحقول التاريخية عندما لا يوجد lotCode.
// ============================================================

export function fmtDate(d: any) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("ar-SA");
}
export function fmtMoney(v: any) {
  if (!v) return "0 ر.س";
  return `${parseFloat(String(v)).toLocaleString()} ر.س`;
}

type CountCorrectionDocument = {
  id: number;
  requestedByName?: string | null;
  correctedByName?: string | null;
  requestedReason?: string | null;
  correctionReason?: string | null;
  correctedAt?: Date | string | null;
  changes: Array<{ countItemId: number; itemName?: string | null; previousQuantity: number; correctedQuantity: number }>;
};
type CountPrintData = { operation: any; items: any[]; countCorrections?: CountCorrectionDocument[] };
const escapeCountCorrectionText = (value: unknown) => String(value ?? "—").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
const correctionQuantity = (value: unknown) => value != null && Number.isFinite(Number(value)) ? Number(value).toLocaleString(undefined, { maximumFractionDigits: 3 }) : "—";

export function buildCountHtml(data: CountPrintData): string {
    const op = data.operation;
    const correctionVersion = Number.isSafeInteger(Number(op.correctionVersion)) && Number(op.correctionVersion) > 0 ? Number(op.correctionVersion) : 0;
    const correctionHistory = correctionVersion > 0 ? `
<div class="warning-box"><strong>نسخة مصححة — التصحيح رقم ${correctionVersion}</strong><br/>الكميات المعروضة تتضمن التصحيحات الموثقة التالية. رقم الجرد وتاريخ العدّ الأصلي محفوظان، وهذا التصحيح لا يعني إعادة عدّ في وقت لاحق.</div>
<div class="section-title">سجل تصحيحات الجرد</div>
${(data.countCorrections || []).map(correction => {
      const correctedDate = correction.correctedAt ? new Date(correction.correctedAt) : null;
      const dateText = correctedDate && Number.isFinite(correctedDate.getTime()) ? correctedDate.toLocaleString("ar-SA-u-ca-gregory", { timeZone: "Asia/Riyadh" }) : "—";
      return `<div style="border:1px solid #e5e7eb;border-radius:6px;padding:10px;margin-bottom:12px;break-inside:avoid">
<p><strong>طلب التصحيح #${escapeCountCorrectionText(correction.id)}</strong> — ${escapeCountCorrectionText(dateText)} (بتوقيت الرياض)</p>
<p>طلب التصحيح: ${escapeCountCorrectionText(correction.requestedByName)} — المنفذ: ${escapeCountCorrectionText(correction.correctedByName)}</p>
<p style="white-space:pre-wrap">سبب طلب التصحيح: ${escapeCountCorrectionText(correction.requestedReason)}</p>
<p style="white-space:pre-wrap">سبب التصحيح: ${escapeCountCorrectionText(correction.correctionReason)}</p>
<table><thead><tr><th>الصنف</th><th>الكمية السابقة</th><th>الكمية المصححة</th></tr></thead><tbody>${(correction.changes || []).map(change => `<tr><td>${escapeCountCorrectionText(change.itemName || `#${change.countItemId}`)}</td><td>${correctionQuantity(change.previousQuantity)}</td><td>${correctionQuantity(change.correctedQuantity)}</td></tr>`).join("")}</tbody></table></div>`;
    }).join("")}` : "";
    const itemsRows = (data.items || []).map((it: any) => {
      const diff = it.diffQuantity !== null && it.diffQuantity !== undefined ? parseFloat(it.diffQuantity) : null;
      const diffCell = diff === null
        ? `<span style="color:#999">لم يُعدّ بعد</span>`
        : diff === 0
          ? `<span style="color:#059669;font-weight:700">مطابق</span>`
          : `<span style="color:${diff > 0 ? "#2563eb" : "#dc2626"};font-weight:700">${diff > 0 ? `+${diff}` : diff}</span>`;
      const snapshotCost = it.averageCostSnapshot !== null && it.averageCostSnapshot !== undefined
        ? parseFloat(it.averageCostSnapshot)
        : null;
      const diffValue = it.diffValue !== null && it.diffValue !== undefined
        ? parseFloat(it.diffValue)
        : null;
      const costCell = snapshotCost === null ? "—" : snapshotCost.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 });
      const diffValueCell = diffValue === null
        ? "—"
        : `<span style="color:${diffValue > 0 ? "#059669" : diffValue < 0 ? "#dc2626" : "#555"};font-weight:700">${diffValue > 0 ? "+" : ""}${diffValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>`;
      return `
      <tr>
        <td>${it.itemName}</td>
        <td style="text-align:center;font-family:monospace">${parseFloat(it.systemQuantity).toLocaleString()} ${it.unit || ""}</td>
        <td style="text-align:center;font-family:monospace">${it.countedQuantity !== null && it.countedQuantity !== undefined ? parseFloat(it.countedQuantity).toLocaleString() + " " + (it.unit || "") : "—"}</td>
        <td style="text-align:center">${diffCell}</td>
        <td style="text-align:center;font-family:monospace">${costCell}</td>
        <td style="text-align:center">${diffValueCell}</td>
        <td style="text-align:center;font-size:11px">${it.lotCode || it.lotNumber || "—"}${(it.lotExpiryDate || it.expiryDate) ? ` / ${fmtDate(it.lotExpiryDate || it.expiryDate)}` : ""}</td>
        <td style="font-size:11px;color:#555">${it.notes || "—"}</td>
      </tr>`;
    }).join("");

    const countedItems = (data.items || []).filter((it: any) => it.countedQuantity !== null && it.countedQuantity !== undefined);
    const discrepancies = countedItems.filter((it: any) => parseFloat(it.diffQuantity || "0") !== 0);
    const valuatedDiscrepancies = discrepancies.filter((it: any) => it.diffValue !== null && it.diffValue !== undefined);
    const shortageValue = valuatedDiscrepancies
      .filter((it: any) => parseFloat(it.diffQuantity || "0") < 0)
      .reduce((sum: number, it: any) => sum + Math.abs(parseFloat(it.diffValue || "0")), 0);
    const surplusValue = valuatedDiscrepancies
      .filter((it: any) => parseFloat(it.diffQuantity || "0") > 0)
      .reduce((sum: number, it: any) => sum + parseFloat(it.diffValue || "0"), 0);
    const netValue = surplusValue - shortageValue;
    const unvaluatedCount = discrepancies.length - valuatedDiscrepancies.length;
    const isFinal = op.status === "completed";
    const themeColor = "#0f766e"; // teal — يميّز وثيقة الجرد عن وثيقة الاستبعاد (أحمر)

    const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head>
<meta charset="UTF-8"/><title>وثيقة جرد ${op.operationNumber}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',Arial,sans-serif;background:#fff;color:#1a1a1a;padding:32px 40px;font-size:13px}
.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid ${themeColor};padding-bottom:16px;margin-bottom:20px}
.header-title{font-size:22px;font-weight:900;color:${themeColor}}
.header-sub{font-size:11px;color:#666;margin-top:4px}
.header-meta{text-align:left;font-size:11px;color:#555;line-height:2.2}
.badge{display:inline-block;background:${themeColor};color:#fff;padding:4px 14px;border-radius:6px;font-size:14px;font-weight:700}
.status-badge{display:inline-block;padding:3px 10px;border-radius:5px;font-size:11px;font-weight:700;margin-right:6px}
.info-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}
.info-box{border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;background:#fafafa}
.info-label{font-size:10px;color:#888;margin-bottom:3px}
.info-value{font-size:13px;font-weight:700;color:#111}
.section-title{font-size:12px;font-weight:700;color:${themeColor};background:#f0fdfa;padding:6px 12px;border-radius:6px;margin-bottom:12px;border-right:4px solid ${themeColor}}
.financial-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:12px 0 16px}
.financial-box{border:1px solid #d1fae5;border-radius:7px;padding:9px 12px;background:#f8fffd;text-align:center}
.financial-label{font-size:10px;color:#64748b}.financial-value{font-size:15px;font-weight:800;margin-top:2px}
.warning-box{border:1px solid #fcd34d;background:#fffbeb;color:#92400e;border-radius:6px;padding:8px 10px;font-size:11px;margin-bottom:12px}
table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:12px}
thead tr{background:${themeColor};color:#fff}
thead th{padding:8px 10px;text-align:right;font-weight:600}
tbody tr:nth-child(even){background:#f0fdfa}
tbody tr:nth-child(odd){background:#fff}
tbody td{padding:8px 10px;border-bottom:1px solid #f3f4f6}
.totals-row{background:#1a1a1a!important;color:#fff!important;font-weight:700}
.totals-row td{padding:10px;border:none!important;color:#fff}
.sig-section{margin-top:36px;display:grid;grid-template-columns:1fr 1fr;gap:40px}
.sig-box{border-top:2px solid ${themeColor};padding-top:10px;text-align:center;font-size:11px;color:#555}
.sig-name{font-size:14px;font-weight:700;color:#1a1a1a;margin-top:4px}
.footer{margin-top:24px;border-top:1px solid #e5e7eb;padding-top:10px;display:flex;justify-content:space-between;font-size:10px;color:#aaa}
@media print{@page{margin:12mm}body{padding:0}}
</style></head><body>
<div class="header">
  <div>
    <div class="header-title">📋 وثيقة جرد مخزون</div>
    <div class="header-sub">نظام إدارة الصيانة المتكامل — CMMS</div>
  </div>
  <div class="header-meta">
    <div>التاريخ: <strong>${new Date(op.operationDate).toLocaleDateString("ar-SA",{year:"numeric",month:"long",day:"numeric"})}</strong> — اليوم: <strong>${op.riyadhDayName || "—"}</strong></div>
    <div>وقت البدء: <strong>${op.riyadhStartTime || "—"}</strong> (بتوقيت الرياض)</div>
    <div><span class="badge">${op.operationNumber}</span></div>${correctionVersion > 0 ? `<div><strong>نسخة مصححة — التصحيح رقم ${correctionVersion}</strong></div>` : ""}
  </div>
</div>
<div class="info-grid">
  <div class="info-box"><div class="info-label">نطاق الجرد</div><div class="info-value">${op.scope === "full" ? "شامل" : "جزئي"}</div></div>
  <div class="info-box"><div class="info-label">المنفذ</div><div class="info-value">${op.creatorName || "—"}</div></div>
  <div class="info-box"><div class="info-label">عدد الأصناف المعدودة</div><div class="info-value">${countedItems.length} من ${data.items?.length || 0}</div></div>
  <div class="info-box"><div class="info-label">الحالة</div><div class="info-value"><span class="status-badge" style="background:${isFinal ? "#dcfce7" : "#fef3c7"};color:${isFinal ? "#166534" : "#92400e"}">${isFinal ? "✅ نهائي (مقفل)" : "مسودة"}</span></div></div>
</div>
<div class="section-title">تفاصيل الأصناف</div>
<table>
  <thead><tr>
    <th>اسم الصنف</th>
    <th style="text-align:center">كمية النظام</th>
    <th style="text-align:center">الكمية المعدودة</th>
    <th style="text-align:center">الفرق</th>
    <th style="text-align:center">متوسط التكلفة وقت الفتح</th>
    <th style="text-align:center">قيمة الفرق</th>
    <th style="text-align:center">دفعة/صلاحية</th>
    <th>ملاحظة</th>
  </tr></thead>
  <tbody>
    ${itemsRows}
    <tr class="totals-row">
      <td>الإجمالي</td>
      <td style="text-align:center">${data.items?.length || 0} صنف</td>
      <td style="text-align:center">${countedItems.length} معدود</td>
      <td style="text-align:center">${discrepancies.length} فرق</td>
      <td></td><td></td><td></td><td></td>
    </tr>
  </tbody>
</table>
${valuatedDiscrepancies.length > 0 ? `
<div class="section-title">التقييم المالي للفروقات — تكلفة Snapshot وقت فتح الجرد</div>
<div class="financial-grid">
  <div class="financial-box"><div class="financial-label">إجمالي قيمة النقص</div><div class="financial-value" style="color:#dc2626">-${shortageValue.toLocaleString(undefined,{maximumFractionDigits:2})}</div></div>
  <div class="financial-box"><div class="financial-label">إجمالي قيمة الزيادة</div><div class="financial-value" style="color:#059669">+${surplusValue.toLocaleString(undefined,{maximumFractionDigits:2})}</div></div>
  <div class="financial-box"><div class="financial-label">صافي الأثر المالي</div><div class="financial-value" style="color:${netValue < 0 ? "#dc2626" : "#2563eb"}">${netValue > 0 ? "+" : ""}${netValue.toLocaleString(undefined,{maximumFractionDigits:2})}</div></div>
</div>` : ""}
${unvaluatedCount > 0 ? `<div class="warning-box">${unvaluatedCount} بند/بنود لها فرق كمية بدون Snapshot تكلفة افتتاحية، لذلك لم تدخل في الإجمالي المالي.</div>` : ""}${correctionHistory}
<div class="sig-section">
  <div class="sig-box"><div>توقيع المنفذ</div><div class="sig-name">${op.creatorName || "—"}</div></div>
  <div class="sig-box"><div>اعتماد المسؤول</div><div class="sig-name">&nbsp;</div></div>
</div>
<div class="footer">
  <span>وثيقة آلية — نظام CMMS | ${op.operationNumber}</span>
  <span>تاريخ الطباعة: ${new Date().toLocaleDateString("ar-SA")}</span>
</div>
<script>window.onload=()=>{window.print();window.onafterprint=()=>window.close();}<\/script>
</body></html>`;

    return html;
  }

// الطباعة المباشرة (نافذة منبثقة) — تستخدم نفس buildCountHtml أعلاه
export function printCountDocument(data: CountPrintData) {
  const html = buildCountHtml(data);
  const win = window.open("", "_blank", "width=900,height=800");
  if (win) { win.document.write(html); win.document.close(); }
}

export function buildSettlementHtml(data: { settlement: any; items: any[] }): string {
    const s = data.settlement;
    const itemsRows = (data.items || []).map((it: any) => {
      const diff = parseFloat(it.diffQuantity || "0");
      const diffCell = diff === 0
        ? `<span style="color:#059669;font-weight:700">لا يوجد فرق</span>`
        : `<span style="color:${diff > 0 ? "#2563eb" : "#dc2626"};font-weight:700">${diff > 0 ? `+${diff}` : diff}</span>`;
      const unitCostUsed = it.unitCostUsed == null
        ? "—"
        : parseFloat(it.unitCostUsed).toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 });
      const adjustmentValue = it.adjustmentValue == null
        ? "—"
        : `${Number(it.adjustmentValue) > 0 ? "+" : ""}${parseFloat(it.adjustmentValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      return `
      <tr>
        <td>${it.itemName}</td>
        <td style="text-align:center;font-family:monospace">${parseFloat(it.beforeQuantity).toLocaleString()} ${it.unit || ""}</td>
        <td style="text-align:center;font-family:monospace">${parseFloat(it.afterQuantity).toLocaleString()} ${it.unit || ""}</td>
        <td style="text-align:center">${diffCell}</td>
        <td style="text-align:center;font-family:monospace">${unitCostUsed}</td>
        <td style="text-align:center;font-family:monospace">${adjustmentValue}</td>
        <td style="text-align:center;font-size:11px">${it.lotCode || it.lotNumber || "—"}${(it.lotExpiryDate || it.expiryDate) ? ` / ${fmtDate(it.lotExpiryDate || it.expiryDate)}` : ""}</td>
      </tr>`;
    }).join("");
    const themeColor = "#7e22ce"; // بنفسجي — يميّز وثيقة التسوية
    const valuationBasis = s.sourceType === "manual"
      ? "متوسط التكلفة الحالي وقت الترحيل"
      : s.sourceCountType === "periodic"
        ? "متوسط التكلفة المثبت عند فتح الجرد (Opening Snapshot)"
        : s.sourceCountType === "opening_balance"
          ? "تكلفة الرصيد الافتتاحي المعتمدة"
          : "حسب مصدر التسوية المحفوظ";

    const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head>
<meta charset="UTF-8"/><title>وثيقة تسوية ${s.settlementNumber}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',Arial,sans-serif;background:#fff;color:#1a1a1a;padding:32px 40px;font-size:13px}
.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid ${themeColor};padding-bottom:16px;margin-bottom:20px}
.header-title{font-size:22px;font-weight:900;color:${themeColor}}
.header-sub{font-size:11px;color:#666;margin-top:4px}
.header-meta{text-align:left;font-size:11px;color:#555;line-height:2.2}
.badge{display:inline-block;background:${themeColor};color:#fff;padding:4px 14px;border-radius:6px;font-size:14px;font-weight:700}
.info-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px}
.info-box{border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;background:#fafafa}
.info-label{font-size:10px;color:#888;margin-bottom:3px}
.info-value{font-size:13px;font-weight:700;color:#111}
.section-title{font-size:12px;font-weight:700;color:${themeColor};background:#faf5ff;padding:6px 12px;border-radius:6px;margin-bottom:12px;border-right:4px solid ${themeColor}}
.notes-box{border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;background:#fffbf0;font-size:12px;margin-bottom:16px}
table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:12px}
thead tr{background:${themeColor};color:#fff}
thead th{padding:8px 10px;text-align:right;font-weight:600}
tbody tr:nth-child(even){background:#faf5ff}
tbody tr:nth-child(odd){background:#fff}
tbody td{padding:8px 10px;border-bottom:1px solid #f3f4f6}
.sig-section{margin-top:36px;display:grid;grid-template-columns:1fr 1fr;gap:40px}
.sig-box{border-top:2px solid ${themeColor};padding-top:10px;text-align:center;font-size:11px;color:#555}
.sig-name{font-size:14px;font-weight:700;color:#1a1a1a;margin-top:4px}
.footer{margin-top:24px;border-top:1px solid #e5e7eb;padding-top:10px;display:flex;justify-content:space-between;font-size:10px;color:#aaa}
@media print{@page{margin:12mm}body{padding:0}}
</style></head><body>
<div class="header">
  <div>
    <div class="header-title">🧾 وثيقة تسوية مخزون</div>
    <div class="header-sub">نظام إدارة الصيانة المتكامل — CMMS</div>
  </div>
  <div class="header-meta">
    <div>التاريخ: <strong>${new Date(s.appliedAt).toLocaleDateString("ar-SA",{year:"numeric",month:"long",day:"numeric"})}</strong></div>
    <div>وقت الإصدار: <strong>${new Date().toLocaleTimeString("ar-SA")}</strong></div>
    <div><span class="badge">${s.settlementNumber}</span></div>
  </div>
</div>
<div class="info-grid">
  <div class="info-box"><div class="info-label">المصدر</div><div class="info-value">${s.sourceType === "from_count" ? "من عملية جرد" : "تسوية مستقلة"}</div></div>
  <div class="info-box"><div class="info-label">المسؤول</div><div class="info-value">${s.appliedByName || "—"}</div></div>
  <div class="info-box"><div class="info-label">عدد الأصناف</div><div class="info-value">${data.items?.length || 0} صنف</div></div>
</div>
<div class="notes-box">📝 <strong>سبب التسوية:</strong> ${s.reason}${s.reference ? `<br/>🔖 <strong>المرجع:</strong> ${s.reference}` : ""}<br/>💰 <strong>أساس التقييم:</strong> ${valuationBasis}</div>
<div class="section-title">تفاصيل الأصناف المسوّاة</div>
<table>
  <thead><tr>
    <th>اسم الصنف</th>
    <th style="text-align:center">الكمية قبل</th>
    <th style="text-align:center">الكمية بعد</th>
    <th style="text-align:center">الفرق</th>
    <th style="text-align:center">تكلفة الوحدة المستخدمة</th>
    <th style="text-align:center">قيمة التسوية</th>
    <th style="text-align:center">دفعة/صلاحية</th>
  </tr></thead>
  <tbody>${itemsRows}</tbody>
</table>
<div class="sig-section">
  <div class="sig-box"><div>توقيع المنفذ</div><div class="sig-name">${s.appliedByName || "—"}</div></div>
  <div class="sig-box"><div>اعتماد المسؤول</div><div class="sig-name">&nbsp;</div></div>
</div>
<div class="footer">
  <span>وثيقة آلية — نظام CMMS | ${s.settlementNumber}</span>
  <span>تاريخ الطباعة: ${new Date().toLocaleDateString("ar-SA")}</span>
</div>
<script>window.onload=()=>{window.print();window.onafterprint=()=>window.close();}<\/script>
</body></html>`;

    return html;
  }

// الطباعة المباشرة (نافذة منبثقة) — تستخدم نفس buildSettlementHtml أعلاه
export function printSettlementDocument(data: { settlement: any; items: any[] }) {
  const html = buildSettlementHtml(data);
  const win = window.open("", "_blank", "width=900,height=800");
  if (win) { win.document.write(html); win.document.close(); }
}

// طباعة وثيقة الاستبعاد
export function buildDisposalHtml(op: any): string {
    const REASON_AR: Record<string, string> = {
      damaged: "تالف", expired: "منتهي الصلاحية", missing: "مفقود", other: "أخرى"
    };
    const itemsRows = (op.items || []).map((item: any) => `
      <tr>
        <td>${item.itemName}${item.lotCode ? `<div style="font-size:10px;color:#666;margin-top:2px">الدفعة: <span style="font-family:monospace">${item.lotCode}</span></div>` : ""}</td>
        <td style="text-align:center">${parseFloat(item.quantity).toLocaleString()} ${item.unit || ""}</td>
        <td style="text-align:center">${REASON_AR[item.reason] || item.reason}</td>
        <td style="text-align:left;font-family:monospace">${parseFloat(item.unitCost || 0) > 0 ? parseFloat(item.unitCost).toLocaleString() + " ر.س" : "—"}</td>
        <td style="text-align:left;font-family:monospace;font-weight:700">${parseFloat(item.totalCost || 0) > 0 ? parseFloat(item.totalCost).toLocaleString() + " ر.س" : "—"}</td>
      </tr>`).join("");
    const totalValue = (op.items || []).reduce((s: number, i: any) => s + parseFloat(i.totalCost || 0), 0);
    const totalQty   = (op.items || []).reduce((s: number, i: any) => s + parseFloat(i.quantity || 0), 0);
    const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head>
<meta charset="UTF-8"/><title>وثيقة استبعاد ${op.operationNumber}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',Arial,sans-serif;background:#fff;color:#1a1a1a;padding:32px 40px;font-size:13px}
.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #7f1d1d;padding-bottom:16px;margin-bottom:20px}
.header-title{font-size:22px;font-weight:900;color:#7f1d1d}
.header-sub{font-size:11px;color:#666;margin-top:4px}
.header-meta{text-align:left;font-size:11px;color:#555;line-height:2.2}
.badge{display:inline-block;background:#7f1d1d;color:#fff;padding:4px 14px;border-radius:6px;font-size:14px;font-weight:700}
.info-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px}
.info-box{border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;background:#fafafa}
.info-label{font-size:10px;color:#888;margin-bottom:3px}
.info-value{font-size:13px;font-weight:700;color:#111}
.section-title{font-size:12px;font-weight:700;color:#7f1d1d;background:#fef2f2;padding:6px 12px;border-radius:6px;margin-bottom:12px;border-right:4px solid #7f1d1d}
table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:12px}
thead tr{background:#7f1d1d;color:#fff}
thead th{padding:8px 10px;text-align:right;font-weight:600}
tbody tr:nth-child(even){background:#fef2f2}
tbody tr:nth-child(odd){background:#fff}
tbody td{padding:8px 10px;border-bottom:1px solid #f3f4f6}
.totals-row{background:#1a1a1a!important;color:#fff!important;font-weight:700}
.totals-row td{padding:10px;border:none!important;color:#fff}
.sig-section{margin-top:36px;display:grid;grid-template-columns:1fr 1fr;gap:40px}
.sig-box{border-top:2px solid #7f1d1d;padding-top:10px;text-align:center;font-size:11px;color:#555}
.sig-name{font-size:14px;font-weight:700;color:#1a1a1a;margin-top:4px}
.footer{margin-top:24px;border-top:1px solid #e5e7eb;padding-top:10px;display:flex;justify-content:space-between;font-size:10px;color:#aaa}
.notes-box{border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;background:#fffbf0;font-size:12px;margin-bottom:16px}
@media print{@page{margin:12mm}body{padding:0}}
</style></head><body>
<div class="header">
  <div>
    <div class="header-title">📋 وثيقة استبعاد مخزون</div>
    <div class="header-sub">نظام إدارة الصيانة المتكامل — CMMS</div>
  </div>
  <div class="header-meta">
    <div>التاريخ: <strong>${new Date(op.operationDate).toLocaleDateString("ar-SA",{year:"numeric",month:"long",day:"numeric"})}</strong></div>
    <div>وقت الإصدار: <strong>${new Date().toLocaleTimeString("ar-SA")}</strong></div>
    <div><span class="badge">${op.operationNumber}</span></div>
  </div>
</div>
<div class="info-grid">
  <div class="info-box"><div class="info-label">المنفذ</div><div class="info-value">${op.creatorName || "—"}</div></div>
  <div class="info-box"><div class="info-label">عدد الأصناف</div><div class="info-value">${op.items?.length || 0} صنف</div></div>
  <div class="info-box"><div class="info-label">الحالة</div><div class="info-value">${op.status === "COMPLETED" ? "✅ مكتملة" : op.status}</div></div>
</div>
<div class="section-title">تفاصيل الأصناف المستبعدة</div>
<table>
  <thead><tr>
    <th>اسم الصنف</th>
    <th style="text-align:center">الكمية</th>
    <th style="text-align:center">سبب الاستبعاد</th>
    <th style="text-align:left">تكلفة الوحدة</th>
    <th style="text-align:left">إجمالي القيمة</th>
  </tr></thead>
  <tbody>
    ${itemsRows}
    <tr class="totals-row">
      <td>الإجمالي</td>
      <td style="text-align:center">${totalQty.toLocaleString()}</td>
      <td></td><td></td>
      <td style="text-align:left">${totalValue > 0 ? totalValue.toLocaleString() + " ر.س" : "—"}</td>
    </tr>
  </tbody>
</table>
${op.notes ? `<div class="notes-box">📝 <strong>ملاحظات:</strong> ${op.notes}</div>` : ""}
<div class="sig-section">
  <div class="sig-box"><div>توقيع المنفذ</div><div class="sig-name">${op.creatorName || "—"}</div></div>
  <div class="sig-box"><div>اعتماد المسؤول</div><div class="sig-name">&nbsp;</div></div>
</div>
<div class="footer">
  <span>وثيقة آلية — نظام CMMS | ${op.operationNumber}</span>
  <span>تاريخ الطباعة: ${new Date().toLocaleDateString("ar-SA")}</span>
</div>
<script>window.onload=()=>{window.print();window.onafterprint=()=>window.close();}<\/script>
</body></html>`;

    return html;
  }

// الطباعة المباشرة (نافذة منبثقة) — تستخدم نفس buildDisposalHtml أعلاه
export function printDisposalDocument(op: any) {
  const html = buildDisposalHtml(op);
  const win = window.open("", "_blank", "width=900,height=800");
  if (win) { win.document.write(html); win.document.close(); }
}
